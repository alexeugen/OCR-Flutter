# Flutter OCR 

Optical character recognition is a process of conversion of typed images, printed text into the machine-encoded text, which means it will give us a text from images that contains the text.

## Getting Started

This project contains the code of OCR usage in flutter, It is defined in very easy way for newly flutter devs. Enjoy!!

# References:

# Medium Blog:
- [OCR using Flutter](https://medium.com/flutterworld/ocr-using-flutter-6f5765af49a6)



# Youtube Tutorial:

[![Introduction to Flutter](https://i.imgur.com/AvdbJ3k.png)](https://www.youtube.com/watch?v=6cwnBBAVIwE "Little red riding hood - Click to Watch!")


