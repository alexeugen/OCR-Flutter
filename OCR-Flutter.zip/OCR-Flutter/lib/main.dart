
import 'package:flutter/material.dart';
import 'package:flutter_app/scanner/sanner.dart';

void main() => runApp(new MyApp());

class MyApp extends StatefulWidget {
  @override
  Scanner createState() => Scanner();
}