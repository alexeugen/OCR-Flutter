class User{
  final String uid;

  User({this.uid});
}